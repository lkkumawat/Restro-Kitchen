import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:tiffencenter/shared%20preference/PreferenceUtils.dart';
import 'package:intl/intl.dart';

class OrderHistory extends StatefulWidget {
  const OrderHistory({super.key});

  @override
  State<OrderHistory> createState() => _OrderHistoryState();
}

class _OrderHistoryState extends State<OrderHistory> {
  Future<List<UserOrderRequest>>? userOrderRequests;
  double walletAmount = 0.0;
  bool _isLoading = false;
  String _currentDateTime = '';
  String isUserID = '';
  int walletBalalnce = 0;
  String token_Main = '';


  @override
  void initState() { /// wait
    setState(() {
      getToken();
    });
    super.initState();

//    userOrderRequests = fetchOrderRequests('182|NxCurf3dwGqUlOyYR8ZjD38B6mXzHZs8Xh2iPwMi370feaba', "11");
  }
  void getToken()  {
    var token_firstName =  PreferenceUtils.getString('full_name');
    var token =  PreferenceUtils.getString('usertoken');
    isUserID =  PreferenceUtils.getString('user_id').toString();
    token_Main = token.toString();

    print("userID: $isUserID");
    print("Get Token On Order: $token_Main");

    // if (token != null && token.isNotEmpty) {

      userOrderRequests = fetchOrderRequests(token.toString(), isUserID);

      print("Token: $token");
      print("First Name: $token_firstName");
    // } else {
    //   print("No token found or token is empty");//wait
    //   print("No token found or token is empty");
    // }
  }

  Future<List<UserOrderRequest>> fetchOrderRequests(String authToken, String userID) async {
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $authToken',
    };

    final response = await http.get(
      Uri.parse('https://testing.codesk.live/api/user/order/list/$userID'), // Corrected variable name
      headers: headers,
    );

    if (response.statusCode == 200) {
      print('Response Order Body: ${response.body}'); // Print the response body

      // Parse the response body
      Map<String, dynamic> jsonResponse = jsonDecode(response.body);

      if (jsonResponse.containsKey('order_list')) {
        List<dynamic> data = jsonResponse['order_list'];
        print('Transition data: $data'); // Check the data

        if (data.isEmpty) {
          throw Exception('No data found');
        }

        return data.map((item) => UserOrderRequest.fromJson(item)).toList();
      } else {
        throw Exception('order_list key not found');
      }
    } else {
      throw Exception('Failed to load order requests: ${response.statusCode}');
    }
  }

  void cancelapi(BuildContext context, String order_id, ) async {
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token_Main',
    };
    print('Order ID **** $order_id');

    final response = await http.get(
      Uri.parse('https://testing.codesk.live/api/user/order/cancel/$order_id'), // Corrected variable name
      headers: headers,
    );

    if (response.statusCode == 200) {
      print('Response Order Body: ${response.body}'); // Print the response body

      // Parse the response body
      Map<String, dynamic> jsonResponse = jsonDecode(response.body);
      var message = jsonResponse['message'];
    print('message Cancel $message');
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('Restro Kitchen'),
          content: Text(message),
          actions: [
            // Close Button
            TextButton(
              onPressed: () {
                // Perform any action on OK press
                userOrderRequests = fetchOrderRequests(token_Main.toString(), isUserID);
                Navigator.of(context).pop();  // Closes the dialog
              },
              child: Text('OK'),
            ),
          ],
        ),
      );

      if (jsonResponse.containsKey('order_list')) {
        List<dynamic> data = jsonResponse['order_list'];
        print('Transition data: $data'); // Check the data

        if (data.isEmpty) {
          throw Exception('No data found');
        }
        // return data.map((item) => UserOrderRequest.fromJson(item)).toList();
      } else {
        throw Exception('order_list key not found');
      }

    } else {
      throw Exception('Failed to load order requests: ${response.statusCode}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.white,
        padding: EdgeInsets.all(16.0),  // Add padding to the container
        child: FutureBuilder<List<UserOrderRequest>>(
          future: userOrderRequests,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return Center(child: CircularProgressIndicator()); // Center the loader
            } else if (snapshot.hasError) {
              return Center(child: Text('Error: ${snapshot.error}')); // Center the error message
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return Center(child: Text('No data found')); // Center no data message
            }

            // Create a DataTable with the fetched data
            return SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: DataTable(
                columnSpacing: 20,  // Adjust spacing between columns
                // headingRowStyle: MaterialStateProperty.all(
                //   TextStyle(fontWeight: FontWeight.bold, fontSize: 16),  // Bold headings
                // ),
                columns: const <DataColumn>[
                  DataColumn(label: Text('Amount')),
                  DataColumn(label: Text('Qty.')),
                  DataColumn(label: Text('Date')),
                  DataColumn(label: Text('Status')),
                ],
                rows: snapshot.data!.map<DataRow>((request) {
                  // Format the date to dd/MM/yyyy HH:mm
                  String formattedDate = DateFormat('dd/MM/yyyy HH:mm')
                      .format(DateTime.parse(request.created_at.toString()));

                  return DataRow(cells: <DataCell>[
                    DataCell(Text(request.total_amount.toString())),
                    DataCell(Text(request.quntity.toString())),
                    DataCell(Text(formattedDate)),
                    DataCell(Align(
                      alignment: Alignment.center,
                      child: GestureDetector(
                        onTap: () {
                          // Handle onTap action
                          if(request.status== 2){
                            cancelapi(context , request.id.toString());
                          }
                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),  // Add padding inside the button
                          decoration: BoxDecoration(
                            color: Colors.black, // Background color
                            border: Border.all(
                              color: Colors.red, // Red border color
                              width: 1,         // Border width
                            ),
                            borderRadius: BorderRadius.circular(8), // Optional: Rounded corners
                          ),
                          height: 30,  // Increase height for better alignment
                          width: 70,   // Increase width to make the button look balanced
                          alignment: Alignment.center,
                          child: Text(
                            _getButtonText(request.status.toString()), // Display text based on status
                            style: TextStyle(color: Colors.white, fontSize: 12),  // Slightly larger font
                          ),
                        ),
                      ),
                    )),
                  ]);
                }).toList(),
              ),
            );
          },
        ),
      ),
    );
  }

  // Helper function to get button text based on status
  String _getButtonText(String status) {
    switch (status) {
      case "0":
        return "Pending";
      case "1":
        return "Accept";
      case "2":
        return "Cancel";
      case "3":
        return "Rejected";
      default:
        return "Unknown"; // Fallback text in case of unexpected status
    }
  }
}

// Model Class
class UserOrderRequest {
  final int id;
  final int user_id;
  final int product_id;
  final String total_price;
  final String price;
  final String total_amount;
  final int quntity;
  final String? discount;
  final int status;
  final String? created_at;
  final String? updated_at;

  UserOrderRequest({
    required this.id,
    required this. user_id,
    required this. product_id,
    required this.total_price,
    required this.price,
    required this.total_amount,
    required this.quntity,
     this.discount,
    required this.status,
     this.created_at,
     this.updated_at,
  });

  factory UserOrderRequest.fromJson(Map<String, dynamic> json) {
    return UserOrderRequest(
      id: json['id'],
      user_id: json['user_id'],
      product_id: json['product_id'],
      total_price: json['total_price'],
      price: json['price'],
      total_amount: json['total_amount'],
      quntity: json['quntity'],
      discount: json['discount'],
      status: json['status'],
      created_at: json['created_at'],
      updated_at: json['updated_at'],
    );
  }
}