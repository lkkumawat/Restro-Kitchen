import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:tiffencenter/LoginScreen.dart';
import 'package:tiffencenter/OrderHistory.dart';
import 'package:tiffencenter/WalletScreen.dart';
import 'package:tiffencenter/TransitionHistory.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:tiffencenter/shared%20preference/PreferenceUtils.dart';
import 'package:tiffencenter/shared%20preference/Catgorymodal.dart';
import 'package:tiffencenter/AddMoneyScreen.dart';

class Dashboard extends StatefulWidget {
  Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}
class Product {
  final int id;
  final String product;
  final int categoryId;

  Product({
    required this.id,
    required this.product,
    required this.categoryId,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: json['id'],
      product: json['product'],
      categoryId: json['category_id'],
    );
  }
}



void parseProductResponse(String jsonResponse) {
  Map<String, dynamic> data = jsonDecode(jsonResponse);

  if (data['status'] == 200) {
    List<Product> products = (data['product_list'] as List)
        .map((item) => Product.fromJson(item))
        .toList();

    for (var product in products) {
      print('ID: ${product.id}, Product: ${product.product}, Category ID: ${product.categoryId}');
    }
  } else {
    print('Error: ${data['status']}');
  }
}
void main() {
  String jsonResponse = '''
  {
      "status": 200,
      "product_list": [
          {
              "id": 1,
              "product": "Paneer Labadar",
              "category_id": 1
          },
          {
              "id": 2,
              "product": "Chaach",
              "category_id": 1
          },
          {
              "id": 3,
              "product": "Gulabh Jamun",
              "category_id": 1
          },
          {
              "id": 4,
              "product": "Daal",
              "category_id": 1
          }
      ]
  }
  ''';

  parseProductResponse(jsonResponse);
}

class _DashboardState extends State<Dashboard> with SingleTickerProviderStateMixin {
  dynamic _dicData;
  double walletAmount = 0.0;
  bool _isLoading = false;
  String _currentDateTime = '';
  String isUserID = '';
  String userName = 'abc';

  int walletBalalnce = 0;
  late Catgorymodal catgorymodal;
  List<ProductCategory> catagorylist = [];
  String token_Main = '';
  int? selectedIndex = -1;
  List<bool> isCheckedList = [];
  late TabController _tabController; // TabController to manage tab changes
  List<Product> productList = [];


  Map<String, bool> _foodOptions = {
    'Roti': false,
    'Sabji': false,
    'Salad': false,
    'Rice': false,
  };
  int _numberOfPlates = 1;

  @override
  void initState() {
    super.initState();
    getToken();
    _updateDateTime();
    catgorymodal = Catgorymodal(
        status: 200,
        productCategory: []);
    _tabController = TabController(length: 4, vsync: this);
    // String jsonResponse = '''
    // {
    //     "status": 200,
    //     "product_list": [
    //         {"id": 1, "product": "Paneer Labadar", "category_id": 1},
    //         {"id": 2, "product": "Chaach", "category_id": 1},
    //         {"id": 3, "product": "Gulabh Jamun", "category_id": 1},
    //         {"id": 4, "product": "Daal", "category_id": 1}
    //     ]
    // }
    // ''';
    // parseProductResponse(jsonResponse);
    // Initialize TabController
    setState(() {

    });
  }



  void parseProductResponse(String jsonResponse) {
    Map<String, dynamic> data = jsonDecode(jsonResponse);
    if (data['status'] == 200) {
      productList = (data['product_list'] as List)
          .map((item) => Product.fromJson(item))
          .toList();
      // Initialize food options
      for (var product in productList) {
        _foodOptions[product.product] = false; // Set default value to false
      }
      setState(() {}); // Refresh the UI
    }
  }

  @override
  void dispose() {
    _tabController.dispose(); // Dispose TabController when done
    super.dispose();
  }

  void _updateDateTime() {
    final now = DateTime.now();
    final formatter = DateFormat('dd/MM/yyyy HH:mm');
    setState(() {
      _currentDateTime = formatter.format(now);
    });
  }

  Future<void> getToken() async {
    userName = await PreferenceUtils.getString('full_name').toString();
    var token = await PreferenceUtils.getString('usertoken');
    token_Main = token.toString();
    isUserID = await PreferenceUtils.getString('user_id').toString();
    var amount = PreferenceUtils.getString('wallet').toString();
    print('wallet balance first ---- $amount');
    walletBalalnce = int.parse(amount);

    if (token != null && token.isNotEmpty) {
      getWalletAmount(token, isUserID);
      getAllCategory(token, isUserID);
    }
  }

  Future<void> getAllCategory(String authToken, String userID) async {
    setState(() {
      _isLoading = true;
    });
    final url = 'https://testing.codesk.live/api/product/category/list';
    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $authToken', // Include the auth_token here
        },
      );
      print('Status code ${response}');
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print('response Category_dashboard $data');
        catagorylist = (data["product_category"] as List<dynamic>)
            .map((item) => ProductCategory.fromJson(item))
            .toList();
        isCheckedList = List<bool>.filled(catagorylist.length, false); // Initialize checkbox list
        _fetchProducts();
        print("Category List Length: ${catagorylist.length}");
      } else {
        print('error ${response.statusCode}');
      }
    } catch (error) {
      print('error print $error');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> getWalletAmount(String authToken, String userID) async {
    setState(() {
      _isLoading = true;
    });
    final url = 'https://testing.codesk.live/api/user/wallet/$userID';
    try {
      final response = await http.get(
        Uri.parse(url),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $authToken',
        },
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        var dataToSend = data['wallet'];
        walletBalalnce = dataToSend[0]['wallet'];
      }
    } catch (e) {
      print('An error occurred: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _walletAdd() async {
    setState(() {
      _isLoading = true;
    });

    Navigator.push(context, MaterialPageRoute(builder: (context) => WalletScreen())).then((_) {
      getWalletAmount(token_Main, isUserID); // Refresh API data when coming back
    });

    await Future.delayed(Duration(seconds: 2));
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _Transition() async {
    setState(() {
      _isLoading = true;
    });
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => TransitionHistory()),
    );
    await Future.delayed(Duration(seconds: 2));
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _userLogout() async {
    setState(() {
      _isLoading = true;
    });
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token_Main',
    };
    final response = await http.post(
      Uri.parse('https://testing.codesk.live/api/user/logout'),
      headers: headers,
    );
    if (response.statusCode == 200) {
      await PreferenceUtils.remove("usertoken");
      await PreferenceUtils.clear();
      Navigator.pushReplacement(
        context,

      MaterialPageRoute(builder: (context) => LoginScreen()),
      );
    }
    setState(() {
      _isLoading = false;
    });
  }


  Future<void> _fetchProducts() async {
    setState(() {
      _isLoading = true; // Start loading
    });

    const url = 'https://testing.codesk.live/api/product/list/1';

    // Define headers, including authorization
    final headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token_Main', // Replace token_Main with your actual token variable
    };

    try {
      // Pass headers along with the request
      final response = await http.get(Uri.parse(url), headers: headers);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        var productListMain = (data['product_list'] as List)
            .map((productData) => Product.fromJson(productData))
            .toList();

        print('product list main $productListMain');
        setState(() {
          productList = productListMain;
          _isLoading = false; // Stop loading
        });
      } else {
        print('Failed to load products: ${response.statusCode}');
      }
    } catch (e) {
      print('Error occurred while fetching products: $e');
      setState(() {
        _isLoading = false; // Stop loading on error
      });
    }
  }


  Future _submit() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token_Main',
      };
      final response = await http.post(
        Uri.parse('https://testing.codesk.live/api/user/order/$isUserID'),
        headers: headers,
        body: jsonEncode({
          'product': catagorylist[0].id.toString(),
          'discount': '40',
          'price': catagorylist[0].amount.toString(),

          'quntity': _numberOfPlates,
        }),
      );

      print(" Status code: ${response.statusCode}");

      if (response.statusCode == 200) {
        var responsede = jsonDecode(response.body);
        var message = responsede['message'];
        getWalletAmount(token_Main, isUserID);
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('Restro Kitchen'),
            content: Text(message),
            actions: [
              // Close Button
              TextButton(
                onPressed: () {
                  // Perform any action on OK press
                  Navigator.of(context).pop();  // Closes the dialog
                },
                child: Text('OK'),
              ),
            ],
          ),
        );
      }else if (response.statusCode == 401) {
        var responsede = jsonDecode(response.body);
        var message = responsede['message'];
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('Restro Kitchen'),
            content: Text(message),
            actions: [
              // Close Button
              TextButton(
                onPressed: () {
                  // Perform any action on OK press
                  Navigator.of(context).pop();  // Closes the dialog
                },
                child: Text('OK'),
              ),
            ],
          ),
        );
      }else {
        print("Failed to register. Status code: ${response.statusCode}");
        var failresponse = jsonDecode(response.body);
        print("Success Print 2: ${failresponse['data']}");
        var dataToSend = failresponse['data'];
        var message = dataToSend['message'];
        print('message On Failed $message');

        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('Restro Kitchen'),
            content: Text('order failed '),
            actions: [
              // Close Button
              TextButton(
                onPressed: () {
                  // Perform any action on OK press
                  Navigator.of(context).pop();  // Closes the dialog
                },
                child: Text('OK'),
              ),
            ],
          ),
        );


      }
    } catch (e) {
      print("Error occurred: $e");
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text("Restro Kitchen"),
          content: Text('order Failed'),
          actions: [
            // Close Button
            TextButton(
              onPressed: () {
                // Perform any action on OK press
                Navigator.of(context).pop();  // Closes the dialog
              },
              child: Text('OK'),
            ),
          ],
        ),
      );

    } finally {
      setState(() {
        _isLoading = false;
      });
    }//google chrome dikha jisme
  }

  // Build Food Order Tab Content
  Widget buildFoodOrderTab() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 30.0), // Increase top padding
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
           //  const SizedBox(height: 10.0),
           // _buildWalletInfo(),
           //  const Padding(
           //    padding: EdgeInsets.symmetric(vertical: 40.0), // Adjust the value as needed
           //  ),
            _buildCategoryItems(),
            const SizedBox(height: 20.0),
            _buildPlateCounter(),
            const SizedBox(height: 20.0),
            _buildFoodOptions(),
            const SizedBox(height: 20.0),
            _buildSubmitButton(),


            // const SizedBox(height: 20.0),
            // _buildTransitionButton(),
          ],
        ),
      ),
    );
  }

  // Build Dashboard
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Welcome $userName'),
            const SizedBox(height: 4.0), // Space between the title and balance
            Text(
              'Available Balance: ₹$walletBalalnce', // Update this with your balance variable
              style: const TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w400,
                fontSize: 14.0,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              // _walletAdd();
              // Action for first button
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text('Restro Kitchen'),
                  content: Text('Are you sure want to logout ?'),
                  actions: [
                    // Close Button
                    TextButton(
                      onPressed: () {
                        Navigator.of(context).pop();  // Closes the dialog
                      },
                      child: Text('Close'),
                    ),
                    // OK Button
                    TextButton(
                      onPressed: () {
                        // Perform any action on OK press
                        _userLogout(); // Closes the dialog
                      },
                      child: Text('OK'),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(30.0),
          child: Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: Text(
              'Time: $_currentDateTime',
              style: const TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w400,
                fontSize: 14.0,
              ),
            ),
          ),
        ),
      ),



      body: TabBarView(
        controller: _tabController, // Control Tab changes
        children: [
          buildFoodOrderTab(),  // Tab 1 content: Food Order Tab
          Container(            // Tab 2 content
            child: WalletScreen(),
          ),
          Container(            // Tab 3 content
            child: OrderHistory(),//Center(child: Text("Tab 3 content")),
          ),
          Container(            // Tab 4 content
            child: TransitionHistory()//Center(child: Text("Tab 4 content")),
          ),
        ],
      ),
      bottomNavigationBar: Material(
        color: Colors.white,
        child: TabBar(
          controller: _tabController,
          tabs: [
            Tab(
              icon: Icon(Icons.fastfood),
              text: "Home",
            ),
            Tab(
              icon: Icon(Icons.account_balance_wallet),
              text: "Wallet",
            ),
            Tab(
              icon: Icon(Icons.reorder),
              text: "Order",
            ),
            Tab(
              icon: Icon(Icons.money),
              text: "Transition",
            ),
          ],
        ),
      ),
    );
  }

  // Wallet Information Button
  Widget _buildWalletInfo() {
    return GestureDetector(
      onTap: _walletAdd,
      child: Card(
        color: const Color(0xFFEFEFEF),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: [
              const Icon(Icons.account_balance_wallet),
              const SizedBox(width: 8.0),
              Text('Available Balance: ₹$walletBalalnce'),
            ],
          ),
        ),
      ),
    );
  }

  // Plate Counter
  // Plate Counter
  Widget _buildPlateCounter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Number of Plates:'),
        Row(
          children: [
            IconButton(
              icon: const Icon(Icons.remove),
              onPressed: () {
                setState(() {
                  if (_numberOfPlates > 1) _numberOfPlates--; // Ensure minimum is 1
                });
              },
            ),
            Text('$_numberOfPlates', style: const TextStyle(fontSize: 16)),
            IconButton(
              icon: const Icon(Icons.add),
              onPressed: () {
                setState(() {
                  if (_numberOfPlates < 3) _numberOfPlates++; // Limit maximum to 3
                });
              },
            ),
          ],
        ),
      ],
    );
  }

  // Food Options
  Widget _buildFoodOptions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: productList.map((Product product) {
        return ListTile(
          title: Text(product.product), // Display the product name
          // No checkbox, only the product name will be displayed
          trailing: null, // Remove the trailing widget, i.e., no checkbox
        );
      }).toList(),
    );
  }



  // Submit Button
  Widget _buildSubmitButton() {
    return ElevatedButton(
      onPressed: _submit,
      style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
      child: const Text('Submit',
        style: TextStyle(
        color: Colors.white,
        //fontWeight: FontWeight.bold,
        fontSize: 15,
      )),
    );
  }

  // Build Category Items
  Widget _buildCategoryItems() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Food Items:'),
        const SizedBox(height: 8.0),
        Column(
          children: List.generate(catagorylist.length, (index) {
            return Row(
              children: [
                Container(
                  width: 100, // Set the desired width for the image
                  height: 100, // Set the desired height for the image
                  margin: EdgeInsets.only(right: 10), // Add spacing between image and text
                  child: (catagorylist[index].image != null && catagorylist[index].image.isNotEmpty)
                      ? Image.network(
                    catagorylist[index].image.toString(),
                    fit: BoxFit.cover, // Ensure image covers the available space
                    errorBuilder: (context, error, stackTrace) {
                      return Icon(Icons.broken_image); // Fallback icon for broken image link
                    },
                  )
                      : Icon(Icons.image_not_supported), // Fallback icon if no image
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        catagorylist[index].category.toString(), // Display category name
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '₹${catagorylist[index].amount.toString()}', // Display the amount
                        style: TextStyle(
                          color: Colors.grey[600], // Set grey color for the amount
                          fontSize: 16, // Optional: adjust font size
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          }),
        ),
      ],
    );
  }



  // Transition Button
  Widget _buildTransitionButton() {
    return GestureDetector(
      onTap: _Transition,
      child: Card(
        color: const Color(0xFFEFEFEF),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Row(
            children: const [
              Icon(Icons.history),
              SizedBox(width: 8.0),
              Text('Transaction History'),
            ],
          ),
        ),
      ),
    );
  }
}
