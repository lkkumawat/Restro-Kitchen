import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart'; // Import the package
import 'package:tiffencenter/OtpScreen.dart';
import 'package:tiffencenter/shared%20preference/PreferenceUtils.dart';

import 'dashboard.dart';

class Signup extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}
class UserResponse {
  final bool status;
  final String message;
  final String otp;
  final int registerId;

  UserResponse({required this.status, required this.message, required this.otp, required this.registerId});

  factory UserResponse.fromJson(Map<String, dynamic> json) {
    return UserResponse(
      status: json['status'],
      message: json['message'],
      otp: json['otp'],
      registerId: json['register_id'],
    );
  }
}
class _LoginScreenState extends State<Signup> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _name = TextEditingController();
  final TextEditingController _mobileNo = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _ConfirmpasswordController = TextEditingController();

  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;


  Future _signup() async {
    setState(() {
      _isLoading = true;
    });
    try {
      var response = await http.post(
        Uri.parse("https://testing.codesk.live/api/user/register"),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'email': _emailController.text.toString(),
          'name': _name.text.toString(),
          'mobile': _mobileNo.text,
          'password': _passwordController.text.toString(),
          'password_confirmation': _ConfirmpasswordController.text.toString(),
        }),
      );
      print('message ON Login **');

      // Map<String, dynamic> jsonMap = jsonDecode(response.body);

      // Create UserResponse object
      // UserResponse userResponse = UserResponse.fromJson(jsonMap);

      // Map<String, dynamic> jsonResponse = jsonDecode(response.body);
      //
      // print('jsonResponse ON Login ** $jsonResponse');
      // var dataToSend = jsonResponse['data'];
      //
      // var message = dataToSend['message'];
      // print('message ON Login ** $message');

      // if (jsonMap['status'] != null && jsonMap['status'] == false) {
      //   // Handle error case
      //   print('Error: ${jsonMap['message']}');
      // } else {
      //   // Proceed with creating the UserResponse object
      //   UserResponse userResponse = UserResponse.fromJson(jsonMap);
      //   print('User created successfully with OTP: ${userResponse.otp}');
      // }
      print('message ON Login1 **');
      // Accessing values
      // print('Status: ${userResponse.status}');
      // print('Message: ${userResponse.message}');
      // print('OTP: ${userResponse.otp}');
      // print('Register ID: ${userResponse.registerId}');

      if (response.statusCode == 200) {
        Map<String, dynamic> userResponse = jsonDecode(response.body);
        int registerId = userResponse['register_id'];
        await PreferenceUtils.setString("registerid", registerId.toString());
        Navigator.of(context).push(
          MaterialPageRoute(builder: (context) => OtpScreen()),
        );
        print('Register ID: $registerId');
      } else if (response.statusCode == 403) {
        Map<String, dynamic> userResponse = jsonDecode(response.body);
        var message = userResponse['message'];

        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('Restro Kitchen'),
            content: Text(message),
            actions: [
              // Close Button
              TextButton(
                onPressed: () {
                  // Perform any action on OK press
                  Navigator.of(context).pop();  // Closes the dialog
                },
                child: Text('OK'),
              ),
            ],
          ),
        );
      } else {
        print('Failed to load user data');
      }
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          'SignUp',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.red,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextFormField(
              controller: _name,
              decoration: InputDecoration(labelText: 'Name'),
              keyboardType: TextInputType.emailAddress,

            ),
            TextFormField(
              controller: _mobileNo,
              inputFormatters: [
                LengthLimitingTextInputFormatter(10), // Limit to 10 digits
                FilteringTextInputFormatter.digitsOnly, // Only allow digits
              ],
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your mobile number';
                }
                // Check if the length is exactly 10 characters
                if (value.length != 10) {
                  return 'Mobile number must be exactly 10 digits';
                }
                // Additional validation (e.g., checking if it's numeric)
                if (!RegExp(r'^\d{10}$').hasMatch(value)) {
                  return 'Please enter a valid 10-digit mobile number';
                }
                return null;
              },
              // Format the input to accept only digits

              decoration: InputDecoration(labelText: 'Mobile Number'),
              keyboardType: TextInputType.number,

            ),
            TextFormField(
              controller: _emailController,
              decoration: InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,

            ),
            TextFormField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,

            ),
            TextFormField(
              controller: _ConfirmpasswordController,
              decoration: InputDecoration(labelText: 'Confirm Password'),
              obscureText: true,

            ),
            SizedBox(height: 20),
            _isLoading
                ? CircularProgressIndicator()
                : ElevatedButton(
              onPressed: () async{

                final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+$');
                 if(_name.text.trim().toString().isEmpty){
                Fluttertoast.showToast(
                msg: "name is empty",
                toastLength: Toast.LENGTH_SHORT,
                gravity: ToastGravity.TOP,
                timeInSecForIosWeb: 1,
                backgroundColor: Colors.red,
                textColor: Colors.white,
                fontSize: 16.0,
                );
                print("name is required");
                } else if(_mobileNo.text.trim().toString().isEmpty){
                Fluttertoast.showToast(
                msg: "mobile number is empty",
                toastLength: Toast.LENGTH_SHORT,
                gravity: ToastGravity.TOP,
                timeInSecForIosWeb: 1,
                backgroundColor: Colors.red,
                textColor: Colors.white,
                fontSize: 16.0,
                );
                print("mobile is required");
                }
                else if (_emailController.text
                    .trim()
                    .toString()
                    .isEmpty){

                  Fluttertoast.showToast(
                    msg: "Email is empty",
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.TOP,
                    timeInSecForIosWeb: 1,
                    backgroundColor: Colors.red,
                    textColor: Colors.white,
                    fontSize: 16.0,
                  );
                }
                else if (!emailRegex.hasMatch(_emailController.text
                    .trim()
                    .toString())) {
                  Fluttertoast.showToast(
                    msg: "Please enter a valid email",
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.TOP,
                    timeInSecForIosWeb: 1,
                    backgroundColor: Colors.red,
                    textColor: Colors.white,
                    fontSize: 16.0,
                  );

                }
                else if(_passwordController.text.trim().toString().isEmpty){
                  Fluttertoast.showToast(
                    msg: "Password must be at least 6 characters long",
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.TOP,
                    timeInSecForIosWeb: 1,
                    backgroundColor: Colors.red,
                    textColor: Colors.white,
                    fontSize: 16.0,
                  );
                  print("mobile is password");
                }
                 else if(_passwordController.text.trim().toString()  != _ConfirmpasswordController.text.trim().toString() ){
                   Fluttertoast.showToast(
                     msg: "Password and Confirm Password Not same. ",
                     toastLength: Toast.LENGTH_SHORT,
                     gravity: ToastGravity.TOP,
                     timeInSecForIosWeb: 1,
                     backgroundColor: Colors.red,
                     textColor: Colors.white,
                     fontSize: 16.0,
                   );
                   print("mobile is password");
                 }
                // if (_passwordController.text.trim().toString().vali() ?? false) {
                //   // Perform action if the mobile number is valid
                //   final mobileNumber = _mobileNumberController.text;

                // }
                else{
                  _signup();
                }
              },
              child: Text('Sign Up'),
            ),
          ],
        ),
      ),
    );
  }
}