import 'dart:async';
import 'package:flutter/material.dart';
import 'package:tiffencenter/Dashboard.dart';
import 'package:tiffencenter/LoginScreen.dart';
import 'package:tiffencenter/shared%20preference/PreferenceUtils.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    startSplashScreen();
  }

  startSplashScreen() async {
    await Future.delayed(const Duration(seconds: 3), () async {
      var userToken = await PreferenceUtils.getString("usertoken");

      if (userToken != null && userToken.isNotEmpty) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => Dashboard()),
        );
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => LoginScreen()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.white,  // Background color
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Add your logo here
            Image.asset(
              'assets/images/splashscreen_new.png', // Path to your logo
              // height: 300,
              // width: 300,
            ),
            const SizedBox(height: 20),
            const Text(
              "Tiffen Center",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 20),
            // const CircularProgressIndicator(), // Loader
          ],
        ),
      ),
    );
  }
}
