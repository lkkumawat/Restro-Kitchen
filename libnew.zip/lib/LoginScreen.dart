import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

import 'dart:convert';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:tiffencenter/shared%20preference/PreferenceUtils.dart';
import 'package:tiffencenter/WalletScreen.dart';

import 'Dashboard.dart';
import 'Forgotpassword.dart';
import 'Signup.dart'; // Import the package

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;
  bool _passwordVisible = false;

  // mobile validation function
  String? _validateMobileNo(String? value) {
    // if (value == null || value.isEmpty) {
    //   Fluttertoast.showToast(
    //     msg: "Please enter your mobile number",
    //     toastLength: Toast.LENGTH_SHORT,
    //     gravity: ToastGravity.BOTTOM,
    //     timeInSecForIosWeb: 2, // Increase the duration
    //     backgroundColor: Colors.red,
    //     textColor: Colors.white,
    //     fontSize: 16.0,
    //   );
    //   return 'Please enter your mobile number';
    // }
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Please enter your mobile number'),
    ));
  }
//postman dikha do
  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      Fluttertoast.showToast(
        msg: "Please enter your password",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.TOP,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0,
      );
      return 'Please enter your password';
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Please enter your password'),
      ));
    }
    // Password must be at least 6 characters
    if (value.length < 6) {
      Fluttertoast.showToast(
        msg: "Password must be at least 6 characters long",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.TOP,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.red,
        textColor: Colors.white,
        fontSize: 16.0,
      );
      return 'Password must be at least 6 characters long';
    }
    return null;
  }

  Future _login() async {
    setState(() {
      _isLoading = true;
      _passwordVisible = false;
    });

    try {
      var response = await http.post(
        Uri.parse("https://testing.codesk.live/api/user/login"),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },//class banao name do ye vala PreferenceUtils

        body: jsonEncode({
          'user_name': _emailController.text.toString(),
          'password': _passwordController.text.toString(),
        }),
      );


      if (response.statusCode == 200) {
        var responsede = jsonDecode(response.body);
        print("Success Print: ${responsede['data']}");
        var dataToSend = responsede['data'];
           var firstName = dataToSend['full_name'];
        var token = dataToSend['token'].toString();
        var wallet = dataToSend['wallet'].toString();
        print("logintoken"+token);

        await PreferenceUtils.setString("usertoken", token.toString());
        await PreferenceUtils.setString("full_name", firstName.toString());
        await PreferenceUtils.setString("wallet", wallet.toString());
        await PreferenceUtils.setString(
            "user_id", dataToSend['user_id'].toString());

        Navigator.of(context).push(
          MaterialPageRoute(builder: (context) => Dashboard()),
        );
      } else {
        print("Failed to register. Status code: ${response.statusCode}");
        var failresponse = jsonDecode(response.body);
        print("Success Print: ${failresponse['data']}");
        var dataToSend = failresponse['data'];
        var message = dataToSend['message'];
        print('$message');

        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('Restro Kitchen'),
            content: Text('Login Failed'),
            actions: [
              // Close Button
              TextButton(
                onPressed: () {
                  // Perform any action on OK press
                  Navigator.of(context).pop();  // Closes the dialog
                },
                child: Text('OK'),
              ),
            ],
          ),
        );


      }
    } catch (e) {
      print("Error occurred: $e");
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('Restro Kitchen'),
          content: Text("Login Failed"),
          actions: [
            // Close Button
            TextButton(
              onPressed: () {
                // Perform any action on OK press
                Navigator.of(context).pop();  // Closes the dialog
              },
              child: Text('OK'),
            ),
          ],
        ),
      );

    } finally {
      setState(() {
        _isLoading = false;
      });
    }//google chrome dikha jisme
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          'Login',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        backgroundColor: Colors.red,
        elevation: 0,
      ),

      body: Container(
          decoration: BoxDecoration(

          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    // Center(
                    //   child:
                    //   Image.asset('assets/images/plate-raw-vegetables.png' , width: 200,   // Set the width
                    //       height: 200,  // Set the height
                    //       fit: BoxFit.cover,),
                    // ),
                    Column(
                      children: [
                        TextFormField(
                          controller: _emailController,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(10), // Limit to 10 digits
                            FilteringTextInputFormatter.digitsOnly, // Only allow digits
                          ],
                          decoration: InputDecoration(
                            labelText: 'Mobile Number',
                            hintStyle: TextStyle(
                              color: Colors.white, // Change placeholder color here
                              fontStyle: FontStyle.italic, // Optional: add italic style
                            ),
                            border: OutlineInputBorder(),
                          ),
                          keyboardType: TextInputType.number,
                          validator: _validateMobileNo,
                        ),

                        SizedBox(height: 20), // Add spacing between the two fields

                         TextFormField(
                           controller: _passwordController,
                              obscureText: !_passwordVisible,
                           decoration: InputDecoration(
                             labelText: 'Password',
                             hintStyle: TextStyle(
                               color: Colors.white, // Change placeholder color here
                               fontStyle: FontStyle.italic, // Optional: add italic style

                             ),
                             border: OutlineInputBorder(),
                           ),

                           validator: _validatePassword,
                            keyboardType: TextInputType.text,


                         ),
                      ],
                     ),




                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: () {
                            print("Forgot Password tapped!");
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => Forgotpassword()),
                            );
                          },
                          child: Text(
                            "Forgot Password?",
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 20),
                    _isLoading
                        ? CircularProgressIndicator()
                        : ElevatedButton(
                      onPressed: _login,
                      child: Text('Login',style: TextStyle(
                        fontWeight: FontWeight.bold, // Makes the text bold
                        fontSize: 16,                // You can also adjust the font size if needed
                      ),),
                    ),
                    SizedBox(height: 20),
                    Center(
                      child: GestureDetector(
                        onTap: () {
                          print("Signup tapped!");
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => Signup()),
                          );
                        },
                        child: Align(
                          alignment: Alignment.center,
                          child: Text(
                            "Signup",
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.black,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          )
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: LoginScreen(),
  ));
}