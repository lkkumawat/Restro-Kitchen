import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:tiffencenter/shared%20preference/PreferenceUtils.dart';

class WalletScreen extends StatefulWidget {
  @override
  _WalletScreenState createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  bool _isLoading = false;
  String isUserID = '';
  String isToken = '';

  final TextEditingController _amountController = TextEditingController();
  int walletAmount = 0;

  @override
  void initState() {
    super.initState();

    getToken();

    // Start a periodic timer to update the date and time every second
    // Timer.periodic(Duration(seconds: 1), (Timer t) => _updateDateTime());
  }

  Future<void> getToken() async {
    var token = await PreferenceUtils.getString('usertoken');
    isUserID = await PreferenceUtils.getString('user_id').toString();
    var amount = await PreferenceUtils.getString('wallet').toString();

    if (amount.isNotEmpty) {
      setState(() {
        walletAmount = int.parse(amount);
      });
    }

    print("walletAmount ***** $walletAmount");

    if (token != null && token.isNotEmpty) {
      isToken =  token.toString();
      print("Token: $isToken");
    } else {
      print("No token found or token is empty");
      print("No token found or token is empty");
    }
  }

  void _addAmount() {
    // Convert the input to double
    int amount = int.tryParse(_amountController.text) ?? 0;

    if (amount > 99) {
      setState(() {
        walletAmount += amount;
        _updateWalletInBackend(isToken , isUserID);
      });

      // Simulate sending data to a backend


      // Clear the input field
      _amountController.clear();
    } else {
      // Handle invalid input (e.g., show a Snackbar)
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter minimum 100 ruppes')),
      );
    }
  }

  Future<void> _updateWalletInBackend(String authToken, String userID ) async {
    // Validate the form fields
    // if (_formKey.currentState?.validate() ?? false) {
    setState(() {
      _isLoading = true;
    });
    print('wallet user id $userID');
    final response = await http.post(
      Uri.parse('https://testing.codesk.live/api/user/fund/request/$userID'), // Replace with your API endpoint


      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': 'Bearer $authToken',
      },

      body: jsonEncode({
        'amount': walletAmount
      }),
    );

    print('wallet amount $walletAmount');
    print('Bearer $authToken');
    print('wallet URL : https://testing.codesk.live/api/user/fund/request/$userID');
    if (response.statusCode == 200) {
      //final data = jsonDecode(response.body);
      Map<String, dynamic> parsedJson = jsonDecode(response.body);

      // Accessing the values
      int status = parsedJson['status'];
      String message = parsedJson['message'];

      print('Status: $status');
      print('Message: $message');
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text(message),
          content: Text(''),
          actions: [
            // Close Button
            TextButton(
              onPressed: () {
                // Perform any action on OK press
                Navigator.of(context).pop();  // Closes the dialog
              },
              child: Text('OK'),
            ),
          ],
        ),
      );

      // Navigator.push(
      //  // context
      //  // MaterialPageRoute(builder: (context) => Dashboard()),
      // );
    } else {
      print("wallet failed: ${response.body}");
      // Fluttertoast.showToast(
      //   msg: "Login failed: ${response.body}",
      //   toastLength: Toast.LENGTH_SHORT,
      //   gravity: ToastGravity.BOTTOM,
      //   timeInSecForIosWeb: 1,
      //   backgroundColor: Colors.red,
      //   textColor: Colors.white,
      //   fontSize: 16.0,
      // );
    }

    setState(() {
      _isLoading = false;
    });
    // }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Text(
            //   'Current Wallet Amount: ₹${walletAmount.toStringAsFixed(2)}',
            //   style: TextStyle(fontSize: 20),
            // ),
            SizedBox(height: 20),
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Enter amount to add',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _addAmount,
              child: Text('Add Amount'),
            ),
          ],
        ),
      ),
    );
  }
}

void main() => runApp(MaterialApp(
  home: WalletScreen(),
));

